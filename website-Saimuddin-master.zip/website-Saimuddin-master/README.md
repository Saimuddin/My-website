# CS 20 Website Project
* Upload your website for your CS 20 project to this Github repository. Make sure that your home page is named index.html
* There should be at least 3 commits for each web page
